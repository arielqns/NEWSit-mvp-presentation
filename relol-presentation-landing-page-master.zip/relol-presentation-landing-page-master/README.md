# Name
Landing Page for Project-1B (relol)

# Link
https://arielqns.github.io/relol-presentation-landing-page/ 

# Created by
Team Members: 
Arthur Petrosyan, Arnold Ramos and Ariel Quinones

# Description
This landing page was used during the pre-app presentation of relol.

# Instructions:
- Use the nav bar or priamry buttoms to trigger a scroll.
- Demo and image at the end link to project #1.

# Created using: 
HTML, CSS, Javascript, Bootstrap, jQuery